import Control.Monad
import Data.IORef
import Graphics.UI.Gtk hiding (Action)

-- Main entry point of the application
main :: IO ()
main = do
  st <- newIORef (Value "" Nothing Nothing)  -- State management for the calculator
  void initGUI

  -- Create the main window
  window <- windowNew
  set window [windowTitle := "Calculator", containerBorderWidth := 10]

  -- Create a grid layout
  grid <- gridNew
  gridSetRowHomogeneous grid True
  gridSetColumnHomogeneous grid True

  -- Create the display (editable entry widget)
  display <- entryNew
  set display [ entryXalign := 1  -- Right-align the text
              , entryText   := "0"
              ]

  -- Add the display to the grid, spanning 5 columns
  gridAttach grid display 0 0 5 1

  -- Helper function for attaching buttons to the grid
  let attach x y w h item = gridAttach grid item x y w h
      mkBtn = mkButton st display  -- Use mkButton with state and display

  -- Row 1: Memory buttons
  attach 0 1 1 1 =<< mkBtn "MC" clearMemory
  attach 1 1 1 1 =<< mkBtn "MR" memoryRecall
  attach 2 1 1 1 =<< mkBtn "MS" memoryStore
  attach 3 1 1 1 =<< mkBtn "M+" memoryAdd
  attach 4 1 1 1 =<< mkBtn "M–" memorySubtract

  -- Row 2: Control buttons
  attach 0 2 1 1 =<< mkBtn "←" backspaceInput  -- Renamed function
  attach 1 2 1 1 =<< mkBtn "CE" clearEntry
  attach 2 2 1 1 =<< mkBtn "C" clearAll
  attach 3 2 1 1 =<< mkBtn "±" id  -- Placeholder for +/- functionality
  attach 4 2 1 1 =<< mkBtn "√" id  -- Placeholder for square root functionality

  -- Row 3: Number buttons and operations
  attach 0 3 1 1 =<< mkBtn "7" (enterDigit '7')
  attach 1 3 1 1 =<< mkBtn "8" (enterDigit '8')
  attach 2 3 1 1 =<< mkBtn "9" (enterDigit '9')
  attach 3 3 1 1 =<< mkBtn "÷" (operator Division)
  attach 4 3 1 1 =<< mkBtn "%" id  -- Placeholder for percentage functionality

  -- Row 4: Number buttons and operations
  attach 0 4 1 1 =<< mkBtn "4" (enterDigit '4')
  attach 1 4 1 1 =<< mkBtn "5" (enterDigit '5')
  attach 2 4 1 1 =<< mkBtn "6" (enterDigit '6')
  attach 3 4 1 1 =<< mkBtn "*" (operator Multiplication)
  attach 4 4 1 1 =<< mkBtn "1/x" id  -- Placeholder for reciprocal functionality

  -- Row 5: Number buttons and operations
  attach 0 5 1 1 =<< mkBtn "1" (enterDigit '1')
  attach 1 5 1 1 =<< mkBtn "2" (enterDigit '2')
  attach 2 5 1 1 =<< mkBtn "3" (enterDigit '3')
  attach 3 5 1 1 =<< mkBtn "–" (operator Subtraction)
  attach 4 5 1 1 =<< mkBtn "=" equals  -- Equal button spans 2 rows

  -- Row 6: Number buttons and operations
  attach 0 6 2 1 =<< mkBtn "0" (enterDigit '0')  -- Zero button spans 2 columns
  attach 2 6 1 1 =<< mkBtn "." (enterDot)
  attach 3 6 1 1 =<< mkBtn "+" (operator Addition)

  -- Add the grid to the main window
  containerAdd window grid

  -- Show all widgets
  widgetShowAll window

  -- Close the application when the window is destroyed
  on window objectDestroy mainQuit

  -- Start the GTK main loop
  mainGUI

-- Helper function to create a button and connect its signal
mkButton :: IORef Value -> Entry -> String -> (Value -> Value) -> IO Button
mkButton st display label mutateState = do
  btn <- buttonNewWithLabel label
  -- Connect the button press event to update the display
  btn `on` buttonActivated $ do
    value <- atomicModifyIORef st $ \x -> let r = mutateState x in (r, r)
    updateDisplay display value
  return btn

-- | 'Value' holds the current input string and the last operation.
data Value = Value String (Maybe Action) (Maybe Double)

-- | Action to apply to the current input.
data Action
  = Addition
  | Subtraction
  | Multiplication
  | Division

-- | Render given 'Value'.
renderValue :: Value -> String
renderValue (Value x action _) =
  case action of
    Nothing -> x
    Just a  -> x ++ " " ++ renderAction a
  where
    renderAction Addition       = "+"
    renderAction Subtraction    = "–"
    renderAction Multiplication  = "*"
    renderAction Division        = "÷"

-- | Make calculator's display show given 'Value'.
updateDisplay :: Entry -> Value -> IO ()
updateDisplay display value =
  set display [ entryText := renderValue value ]

-- | Change state as if a dot is entered.
enterDot :: Value -> Value
enterDot (Value x action lastValue) =
  let f xs = if '.' `elem` xs then xs else xs ++ "."
  in Value (f x) action lastValue

-- | Change state as if specific char (digit) is entered.
enterDigit :: Char -> Value -> Value
enterDigit ch (Value x action lastValue) =
  case action of
    Nothing -> Value (x ++ [ch]) action lastValue  -- Append digit to current input
    Just a  -> Value [ch] (Just a) lastValue  -- Reset for new input after operator

-- | Change state as if last character of current argument is removed.
backspaceInput :: Value -> Value  -- Renamed function
backspaceInput (Value x action lastValue) =
  Value (if null x then "0" else init x) action lastValue

-- | Apply given operator to current state.
operator :: Action -> Value -> Value
operator op (Value x _ lastValue) =
  if null x then Value "" (Just op) lastValue  -- If there's no input, reset
  else Value "" (Just op) (Just (read x :: Double))  -- Reset for new input after operator

-- | Evaluate current calculator's state and return result.
equals :: Value -> Value
equals (Value x action lastValue) =
  case action of
    Nothing -> Value x Nothing lastValue
    Just a -> case lastValue of
      Just lv -> Value result Nothing Nothing
        where
          x' = read x :: Double
          result = case a of
            Addition       -> show (lv + x')
            Subtraction    -> show (lv - x')
            Multiplication -> show (lv * x')
            Division       -> if x' /= 0 then show (lv / x') else "Error"  -- Handle division by zero
      Nothing -> Value x action lastValue  -- Just return current state if no last value

-- | Clear entry state.
clearEntry :: Value -> Value
clearEntry _ = Value "" Nothing Nothing

-- | Clear all entry states.
clearAll :: Value -> Value
clearAll = const (Value "" Nothing Nothing)

-- | Memory operations (placeholders for now)
clearMemory :: Value -> Value
clearMemory _ = Value "" Nothing Nothing  -- This function would normally clear memory

memoryRecall :: Value -> Value
memoryRecall value = value  -- Placeholder; would normally return stored memory

memoryStore :: Value -> Value
memoryStore value = value  -- Placeholder; would normally store current value to memory

memoryAdd :: Value -> Value
memoryAdd value = value  -- Placeholder; would normally add current value to memory

memorySubtract :: Value -> Value
memorySubtract value = value  -- Placeholder; would normally subtract current value from memory
